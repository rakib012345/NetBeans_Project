
package hierarchy;


public class Person {
  private String name;
  private int age;
  private String Qualification;
  private double cgpa;
  	public void setName(String name)
	{
	this.name=name ;
	}
       public void setage(int age)
	{
	this.age=age ;
	}
  	public void setQualification(String  Qualification)
	{
	this. Qualification= Qualification ;
	}
       public void setcgpa(double cgpa)
	{
	this.cgpa=cgpa ;
	}        
       public String getName() 
	{
	return name;
	}
       public int getage() 
	{
	return age;
	}
       public String getQualification() 
	{
	return Qualification;
	}
       public double getcgpa() 
	{
	return cgpa;
	}

 }