
package hierarchy;

public class Graduate {
    
}
